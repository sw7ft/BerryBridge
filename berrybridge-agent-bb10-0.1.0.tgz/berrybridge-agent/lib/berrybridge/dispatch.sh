# shellcheck shell=sh
# Dispatch inbox JSON jobs

bb_run_job_file() {
	_jobfile="$1"
	_lib=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
	# When sourced from bin/berrybridge-run-job, $0 is the runner — use bb_agent_home
	if [ ! -f "${_lib}/job-ping.sh" ]; then
		_lib="$(bb_agent_home)/lib/berrybridge"
	fi
	if [ ! -f "$_jobfile" ]; then
		bb_log "ERROR: job file not found: $_jobfile"
		return 1
	fi

	_type=$(bb_json_field "$_jobfile" type)
	_id=$(bb_json_field "$_jobfile" id)
	[ -n "$_id" ] || _id=$(basename "$_jobfile" .json)

	BB_LAST_JOB_ID="$_id"
	BB_JOB_TYPE="$_type"
	BB_STATUS_STATE=running
	BB_LAST_ERROR=
	bb_refresh_status_defaults
	BB_JOB_STATE=running
	BB_JOB_MSG="executing $_type"
	bb_write_status

	bb_log "processing job id=${_id} type=${_type} file=${_jobfile}"
	_rc=0

	case "$_type" in
	ping)
		# shellcheck disable=SC1091
		. "${_lib}/job-ping.sh"
		bb_job_ping || _rc=$?
		;;
	install_berrycore)
		# shellcheck disable=SC1091
		. "${_lib}/job-install-berrycore.sh"
		bb_job_install_berrycore "$_jobfile" || _rc=$?
		;;
	install_ssh_key)
		# shellcheck disable=SC1091
		. "${_lib}/job-ssh.sh"
		bb_job_install_ssh_key "$_jobfile" || _rc=$?
		;;
	ensure_sshd)
		# shellcheck disable=SC1091
		. "${_lib}/job-ssh.sh"
		bb_job_ensure_sshd "$_jobfile" || _rc=$?
		;;
	*)
		bb_log "ERROR: unknown job type: $_type"
		BB_LAST_ERROR="unknown job type: $_type"
		_rc=1
		;;
	esac

	if [ "$_rc" -eq 0 ]; then
		BB_STATUS_STATE=idle
		BB_JOB_STATE=completed
		[ -n "${BB_JOB_MSG:-}" ] || BB_JOB_MSG="ok"
	else
		BB_STATUS_STATE=error
		BB_JOB_STATE=failed
		[ -n "${BB_LAST_ERROR:-}" ] || BB_LAST_ERROR="job failed exit $_rc"
		[ -n "${BB_JOB_MSG:-}" ] || BB_JOB_MSG="$BB_LAST_ERROR"
	fi
	BB_JOB_EXIT="$_rc"
	bb_refresh_status_defaults
	bb_write_status

	_dest="${PROCESSED}/$(basename "$_jobfile" .json)-${BB_JOB_STATE}.json"
	mv "$_jobfile" "$_dest" 2>/dev/null || cp "$_jobfile" "$_dest" && rm -f "$_jobfile"
	bb_log "job finished type=${_type} state=${BB_JOB_STATE} exit=${_rc} -> ${_dest}"
	return "$_rc"
}

bb_process_inbox_once() {
	_found=0
	_rc=0
	# Sorted for deterministic order (timestamp prefix in filename)
	for _f in $(ls "$INBOX"/*.json 2>/dev/null | sort); do
		[ -f "$_f" ] || continue
		_found=1
		bb_run_job_file "$_f" || _rc=$?
	done
	if [ -f "${INBOX}/TRIGGER" ]; then
		rm -f "${INBOX}/TRIGGER" 2>/dev/null || true
	fi
	if [ "$_found" -eq 0 ]; then
		return 0
	fi
	return "$_rc"
}

bb_watch_inbox() {
	bb_log "agent watch started (poll=${POLL_INTERVAL}s inbox=${INBOX})"
	bb_ensure_dirs || exit 1
	bb_refresh_status_defaults
	BB_STATUS_STATE=idle
	bb_write_status

	while :; do
		bb_process_inbox_once || true
		sleep "$POLL_INTERVAL" 2>/dev/null || sleep 5
	done
}
