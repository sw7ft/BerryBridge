# shellcheck shell=sh
# Job: install_berrycore

bb_job_install_berrycore() {
	_job="$1"
	bb_log "job install_berrycore: start"

	_workdir="$(bb_json_field "$_job" workdir)"
	_zip="$(bb_json_field "$_job" zip)"
	_installer="$(bb_json_field "$_job" installer)"
	_mode="$(bb_json_field "$_job" mode)"

	[ -n "$_workdir" ] || _workdir="$DOCUMENTS"
	[ -n "$_zip" ] || _zip="berrycore.zip"
	[ -n "$_installer" ] || _installer="install.sh"
	[ -n "$_mode" ] || _mode="fresh"

	if ! bb_path_allowed "$_workdir"; then
		bb_log "ERROR: workdir not allowed: $_workdir"
		return 1
	fi

	_zip_path="${_workdir}/${_zip}"
	_inst_path="${_workdir}/${_installer}"

	if [ ! -f "$_zip_path" ]; then
		bb_log "ERROR: missing $_zip_path"
		return 1
	fi
	if [ ! -f "$_inst_path" ]; then
		bb_log "ERROR: missing $_inst_path"
		return 1
	fi

	bb_log "running installer in $_workdir (mode=$_mode)"
	(
		cd "$_workdir" || exit 1
		if [ "$_mode" = "upgrade" ]; then
			sh "$_installer" --upgrade -y --dir "$BERRYCORE_PATH"
		else
			sh "$_installer" -y --dir "$BERRYCORE_PATH"
		fi
	) >>"$AGENT_LOG" 2>&1
	_rc=$?

	if [ "$_rc" -ne 0 ]; then
		bb_log "ERROR: install.sh exit $_rc"
		return "$_rc"
	fi

	if ! bb_source_berrycore; then
		bb_log "ERROR: install finished but env.sh missing"
		return 1
	fi

	BB_BC_INSTALLED=true
	BB_BC_PATH="$BERRYCORE_PATH"
	BB_BC_VERSION="$(bb_berrycore_version)"
	bb_refresh_status_defaults
	BB_JOB_MSG="BerryCore installed at ${BERRYCORE_PATH} v${BB_BC_VERSION}"
	bb_log "$BB_JOB_MSG"
	return 0
}
