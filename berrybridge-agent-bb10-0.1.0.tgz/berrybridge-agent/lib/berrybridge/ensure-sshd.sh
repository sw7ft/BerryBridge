# shellcheck shell=sh
# Start sshd on SSH_PORT if not already listening (idempotent)

bb_ensure_sshd() {
	_port="${1:-$SSH_PORT}"
	bb_log "ensure-sshd: port $_port"

	if ! bb_require_openssh; then
		return 1
	fi

	if bb_port_listening "$_port"; then
		bb_log "ensure-sshd: already listening on $_port"
		return 0
	fi

	mkdir -p "$SSH_DIR" 2>/dev/null
	chmod 700 "$SSH_DIR" 2>/dev/null || true

	_rsa="${SSH_DIR}/id_rsa"
	if [ ! -f "$_rsa" ]; then
		bb_log "ensure-sshd: generating RSA host key at $_rsa"
		if ! ssh-keygen -t rsa -b 2048 -f "$_rsa" -N "" >>"$AGENT_LOG" 2>&1; then
			bb_log "ERROR: ssh-keygen failed"
			return 1
		fi
	fi

	_sshd=""
	for _c in "${BERRYCORE_PATH}/sbin/sshd" "${BERRYCORE_PATH}/bin/sshd"; do
		if [ -x "$_c" ]; then
			_sshd="$_c"
			break
		fi
	done
	if [ -z "$_sshd" ]; then
		bb_log "ERROR: sshd not found under ${BERRYCORE_PATH} (install openssh package)"
		return 1
	fi

	_root="${BERRYCORE_PATH}"
	_config="${BERRYCORE_PATH}/etc/sshd_config"
	mkdir -p "$(dirname "$SSHD_PIDFILE")" 2>/dev/null
	mkdir -p "${BERRYCORE_PATH}/var/run" 2>/dev/null

	if [ -f "$_config" ]; then
		_rsa_host="${_root}/etc/ssh_host_rsa_key"
		if [ ! -f "$_rsa_host" ]; then
			ssh-keygen -t rsa -b 2048 -f "$_rsa_host" -N "" >>"$AGENT_LOG" 2>&1 || true
		fi
		bb_log "ensure-sshd: starting $_sshd -f $_config (RSA host keys for Bridge)"
		nohup "$_sshd" -f "$_config" \
			-o "HostKey=${_rsa}" \
			-o "HostKey=${_rsa_host}" \
			>>"$AGENT_LOG" 2>&1 &
	else
		bb_log "ensure-sshd: starting $_sshd (inline config, RSA host key)"
		nohup "$_sshd" -f /dev/null \
			-o PasswordAuthentication=no \
			-o StrictModes=no \
			-o Port="$_port" \
			-o HostKey="$_rsa" \
			-o PidFile="$SSHD_PIDFILE" \
			-o SshdSessionPath="${_root}/libexec/sshd-session" \
			-o SshdAuthPath="${_root}/libexec/sshd-auth" \
			-o "Subsystem=sftp ${_root}/libexec/sftp-server" \
			>>"$AGENT_LOG" 2>&1 &
	fi
	_pid=$!
	printf '%s\n' "$_pid" >"$SSHD_PIDFILE" 2>/dev/null || true
	sleep 2

	if bb_port_listening "$_port"; then
		bb_log "ensure-sshd: listening on $_port (pid $_pid)"
		return 0
	fi

	bb_log "ERROR: sshd failed to bind port $_port"
	return 1
}
