# shellcheck shell=sh
# Job: install_ssh_key

bb_merge_authorized_key() {
	_pubfile="$1"
	if [ ! -f "$_pubfile" ]; then
		bb_log "ERROR: public key file missing: $_pubfile"
		return 1
	fi
	if ! bb_path_allowed "$_pubfile"; then
		bb_log "ERROR: public key path not allowed: $_pubfile"
		return 1
	fi

	_line=$(head -1 "$_pubfile" | tr -d '\r\n')
	case "$_line" in
	ssh-rsa*|ssh-ed25519*|ecdsa-*|sk-*)
		;;
	*)
		bb_log "ERROR: invalid public key format in $_pubfile"
		return 1
		;;
	esac

	mkdir -p "$SSH_DIR" 2>/dev/null
	chmod 700 "$SSH_DIR" 2>/dev/null || true
	touch "$AUTHORIZED_KEYS" 2>/dev/null
	chmod 600 "$AUTHORIZED_KEYS" 2>/dev/null || true

	_fp=$(bb_key_fingerprint "$_line")
	if [ -f "$AUTHORIZED_KEYS" ] && grep -qF "$_line" "$AUTHORIZED_KEYS" 2>/dev/null; then
		bb_log "install_ssh_key: key already present (fp=${_fp})"
		BB_KEY_FP="$_fp"
		return 0
	fi

	# Dedupe by key blob (field 2)
	_blob=$(printf '%s' "$_line" | awk '{print $2}')
	if [ -n "$_blob" ] && [ -f "$AUTHORIZED_KEYS" ]; then
		if grep -qF "$_blob" "$AUTHORIZED_KEYS" 2>/dev/null; then
			bb_log "install_ssh_key: key blob already authorized (fp=${_fp})"
			BB_KEY_FP="$_fp"
			return 0
		fi
	fi

	printf '%s\n' "$_line" >>"$AUTHORIZED_KEYS"
	chmod 600 "$AUTHORIZED_KEYS" 2>/dev/null || true
	BB_KEY_FP="$_fp"
	bb_log "install_ssh_key: appended key fp=${_fp}"
	return 0
}

bb_job_install_ssh_key() {
	_job="$1"
	bb_log "job install_ssh_key: start"

	if ! bb_require_openssh; then
		bb_log "ERROR: install BerryCore + OpenSSH before SSH setup"
		return 1
	fi

	_user="$(bb_json_field "$_job" ssh_user)"
	[ -n "$_user" ] && SSH_USER="$_user" && export SSH_USER

	_pubfile="$(bb_json_field "$_job" public_key_path)"
	_auth="$(bb_json_field "$_job" authorized_keys_path)"
	_port="$(bb_json_field_num "$_job" ssh_port)"
	_start="$(bb_json_field "$_job" start_sshd)"

	[ -n "$_pubfile" ] || _pubfile="${DOCUMENTS}/id_rsa_bb10.pub"
	[ -n "$_auth" ] || _auth="$AUTHORIZED_KEYS"
	[ -n "$_port" ] || _port="$SSH_PORT"
	case "$_start" in
	false|0|no) _start=false ;;
	*) _start=true ;;
	esac

	if ! bb_path_allowed "$_auth"; then
		bb_log "ERROR: authorized_keys path not allowed: $_auth"
		return 1
	fi
	AUTHORIZED_KEYS="$_auth"

	mkdir -p "$SSH_DIR" 2>/dev/null
	chmod 700 "$SSH_DIR" 2>/dev/null || true

	_dev_rsa="${SSH_DIR}/id_rsa"
	if [ ! -f "$_dev_rsa" ]; then
		bb_log "generating device RSA key at $_dev_rsa"
		if ! ssh-keygen -t rsa -b 2048 -f "$_dev_rsa" -N "" >>"$AGENT_LOG" 2>&1; then
			bb_log "ERROR: device ssh-keygen failed"
			return 1
		fi
	fi

	if ! bb_merge_authorized_key "$_pubfile"; then
		return 1
	fi

	if [ "$_start" = true ]; then
		if ! bb_ensure_sshd "$_port"; then
			return 1
		fi
	fi

	bb_refresh_status_defaults
	BB_JOB_MSG="sshd on port ${_port} user=${SSH_USER} authorized_keys=$(bb_authorized_keys_count)"
	return 0
}

bb_job_ensure_sshd() {
	_job="$1"
	_port="$(bb_json_field_num "$_job" port)"
	[ -n "$_port" ] || _port="$SSH_PORT"

	if ! bb_require_openssh; then
		return 1
	fi
	if ! bb_ensure_sshd "$_port"; then
		return 1
	fi
	bb_refresh_status_defaults
	BB_JOB_MSG="sshd listening on $_port"
	return 0
}
