#!/bin/sh
# Berry Bridge agent — post-install hook (called from BerryCore install.sh)
# Creates documents/berrybridge/*, seeds status.json, starts watcher, writes cron template.
set -eu

INSTALL_ROOT="${1:-${NATIVE_TOOLS:-}}"
if [ -z "$INSTALL_ROOT" ] || [ ! -f "$INSTALL_ROOT/env.sh" ]; then
	printf 'berrybridge-postinstall: skip (no BerryCore root)\n'
	exit 0
fi

AGENT_HOME=""
for _d in "$INSTALL_ROOT/berrybridge-agent" "$INSTALL_ROOT"; do
	if [ -x "$_d/bin/berrybridge-run-job" ]; then
		AGENT_HOME="$_d"
		break
	fi
done

if [ -z "$AGENT_HOME" ]; then
	printf 'berrybridge-postinstall: skip (agent not installed)\n'
	exit 0
fi

# shellcheck disable=SC1090
. "$INSTALL_ROOT/env.sh"
export NATIVE_TOOLS BERRYCORE_PATH="$NATIVE_TOOLS"

_conf="${AGENT_HOME}/etc/berrybridge/agent.conf"
if [ -f "$_conf" ]; then
	sed "s|^BERRYCORE_PATH=.*|BERRYCORE_PATH=${NATIVE_TOOLS}|" "$_conf" >"${_conf}.tmp" \
		&& mv "${_conf}.tmp" "$_conf"
fi

printf 'Berry Bridge agent post-install\n'
printf '  BerryCore: %s\n' "$NATIVE_TOOLS"
printf '  Agent:     %s\n' "$AGENT_HOME"

export BB_AGENT_HOME="$AGENT_HOME"
sh "${AGENT_HOME}/setup-berrybridge.sh"

# shellcheck source=/dev/null
. "${AGENT_HOME}/lib/berrybridge/common.sh"
bb_load_conf
# shellcheck source=/dev/null
. "${AGENT_HOME}/lib/berrybridge/start-watcher.sh"

bb_start_watcher || true
bb_install_cron_fallback || true

printf 'berrybridge-postinstall: done (inbox=%s)\n' "$INBOX"
