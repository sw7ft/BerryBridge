#!/bin/sh
# Berry Bridge agent — first-time setup (documents inbox + status seed)
# Called by berrybridge-postinstall.sh or manually after qpkg/tgz install.

set -eu

AGENT_HOME=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
# shellcheck source=/dev/null
. "${AGENT_HOME}/etc/berrybridge/agent.conf"

if [ -n "${NATIVE_TOOLS:-}" ] && [ -f "${NATIVE_TOOLS}/env.sh" ]; then
	_conf="${AGENT_HOME}/etc/berrybridge/agent.conf"
	sed "s|^BERRYCORE_PATH=.*|BERRYCORE_PATH=${NATIVE_TOOLS}|" "$_conf" >"${_conf}.tmp" \
		&& mv "${_conf}.tmp" "$_conf"
	# shellcheck disable=SC1090
	. "$_conf"
fi

MARK="# BerryBridge agent"

printf 'Berry Bridge agent setup\n'
printf '  agent home: %s\n' "$AGENT_HOME"
printf '  bridge root: %s\n' "$BRIDGE_ROOT"
printf '  berrycore:  %s\n' "$BERRYCORE_PATH"

mkdir -p "$INBOX" "$PROCESSED" "$BRIDGE_ROOT"
touch "$AGENT_LOG"
chmod +x "${AGENT_HOME}/bin/"* "${AGENT_HOME}/berrybridge-postinstall.sh" 2>/dev/null || true

cat >"${BRIDGE_ROOT}/RUNME.txt" <<EOF
Berry Bridge agent
==================

If jobs were uploaded but nothing ran, run ONCE in Term49:

  ${AGENT_HOME}/bin/berrybridge-run-job --watch

Or process pending jobs once:

  ${AGENT_HOME}/bin/berrybridge-run-job --once

Bridge polls: ${STATUS_FILE}
EOF

# Seed status.json
# shellcheck source=/dev/null
. "${AGENT_HOME}/lib/berrybridge/common.sh"
bb_load_conf
bb_refresh_status_defaults
BB_STATUS_STATE=idle
BB_JOB_MSG="setup complete"
bb_write_status

printf '\nDone.\n'
printf '  inbox:  %s\n' "$INBOX"
printf '  status: %s\n' "$STATUS_FILE"
