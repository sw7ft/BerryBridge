# Berry Bridge ↔ BerryCore agent — integration checklist

**Agent version:** 0.1.0  
**Status:** BerryCore side implemented; Bridge job/poll UI not coded yet.

---

## Answers for Berry Bridge team

### BB10 background process limits

| Question | Answer |
|----------|--------|
| Can watcher run without Term49 open? | **Unknown / device-dependent.** We start with `nohup berrybridge-run-job --watch`. If the process dies when Term49 closes, use **interim `RUNME.txt`** (one line) or **dcron** `* * * * * berrybridge-run-job --once`. |
| Cron fallback | Template at `$NATIVE_TOOLS/berrybridge-agent/etc/berrybridge/cron/berrybridge.crontab` — `@reboot berrybridge-ensure-sshd` + minute poll. Requires BerryCore **dcron** package running. |
| TRIGGER file | Bridge may touch `inbox/TRIGGER` after uploading jobs; agent clears it on `--once` / watch cycle (cosmetic wake signal; cron is the real fallback). |

### OpenSSH package name

| Item | Value |
|------|--------|
| BerryCore package | **`packages/openssh-7.1p2.zip`** |
| Install | Automatic via `install.sh` → `pbpkgadd` (unless upgrade skip) |
| Binaries | `$NATIVE_TOOLS/bin/ssh-keygen`, `$NATIVE_TOOLS/sbin/sshd` (also `$NATIVE_TOOLS/bin/sshd` wrapper in some builds) |
| Agent check | `install_ssh_key` / `ensure_sshd` fail with clear error if missing |

### Bundling (Bridge request)

| Item | Path |
|------|------|
| pbpkgadd zip | `packages/berrybridge-agent-0.1.0.zip` (build with `build-berrycore-port.sh`) |
| On device after install | `$NATIVE_TOOLS/berrybridge-agent/` |
| Post-hook | `install.sh` → `berrybridge-postinstall.sh` → inbox + watcher + cron template |
| Standalone fallback | SMB upload `berrybridge-agent-bb10-0.1.0.tgz` to `documents/` + manual extract to `misc/` |

---

## Path contract (must match Bridge constants)

| Purpose | Absolute path |
|---------|----------------|
| Bridge uploads | `/accounts/1000/shared/documents/` |
| Inbox | `/accounts/1000/shared/documents/berrybridge/inbox/` |
| Status | `/accounts/1000/shared/documents/berrybridge/status.json` |
| Log | `/accounts/1000/shared/documents/berrybridge/agent.log` |
| BerryCore runtime | `/accounts/1000/shared/misc/berrycore` (or custom `--dir`) |
| SSH keys | `/accounts/1000/.ssh/authorized_keys` |
| SSH port / default user | **2022** / **blackberry** (job `ssh_user` overrides status + Bridge connect) |

---

## Bridge implementation checklist

- [ ] Upload `berrycore.zip`, `install.sh` to `documents/`
- [ ] Upload job `install_berrycore.json` to `inbox/`
- [ ] Poll `status.json` every ~3s (45 min timeout)
- [ ] Upload `id_rsa_bb10.pub` then job `install_ssh_key.json` with `public_key_path` + `ssh_user`
- [ ] Poll until `ssh.ready_for_bridge === true`
- [ ] SSH test: `echo berrybridge-ok`
- [ ] Disable `term49-*.txt` when `agent.version >= 0.1.0` and last job succeeded
- [ ] On connection refused post-reboot: upload `ensure_sshd` job or retry SSH after cron

---

## BerryCore release checklist

- [ ] Add `packages/berrybridge-agent-0.1.0.zip` to `berrycore.zip`
- [ ] Verify `install.sh -y` runs post-hook without prompts on fresh Z10
- [ ] Verify `openssh-7.1p2.zip` installs in same run
- [ ] Device test: Bridge wizard without Term49 paste (RUNME interim OK)

---

## v1 scope (confirmed both sides)

**In scope:** BerryCore install + SSH bootstrap only.  
**Out of scope:** `run_command`, Term49 `~` / appdata, `.profile` writes.

After SSH: Bridge uses SSH for terminal, clipboard/PIM, APK helper. SMB for Storage UI + bootstrap only.
