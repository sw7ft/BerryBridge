# BerryCore INDEX integration

Add to BerryCore ports INDEX:

```
berrybridge-agent-bb10|util|0.1.0|<size>|Berry Bridge SMB inbox agent — SSH bootstrap for desktop app
```

## Optional `install.sh` hook

After BerryCore extracts packages, run agent setup once:

```sh
BB_AGENT="/accounts/1000/shared/misc/berrybridge-agent"
if [ -x "${BB_AGENT}/setup-berrybridge.sh" ]; then
  sh "${BB_AGENT}/setup-berrybridge.sh"
fi
```

## Berry Bridge detection

Bridge should probe `status.json`:

```json
{ "agent": { "version": "0.1.0" } }
```

When present, skip `term49-berrycore-install.txt` / `term49-ssh-key-install.txt` and use inbox jobs instead.

## Cron fallback (post-reboot sshd)

```cron
@reboot /accounts/1000/shared/misc/berrybridge-agent/bin/berrybridge-ensure-sshd
```

Use BerryCore dcron; full paths required in crontab.
