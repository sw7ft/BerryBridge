# Berry Bridge agent — port guide

**Target:** BB10 / QNX (ARM), POSIX `sh` only — no compile step.  
**Package:** `berrybridge-agent-bb10-0.1.0.tgz`  
**Consumer:** [Berry Bridge](https://github.com/sw7ft/BerryCore) desktop app (SMB control plane → SSH handoff)

## Build

```bash
cd /root/ports/berrybridge-agent
bash build-berrycore-port.sh
```

Output: `/root/ports/berrybridge-agent-bb10-0.1.0.tgz`

## Layout on device

```text
/accounts/1000/shared/misc/berrybridge-agent/
  bin/berrybridge-agent          # poll inbox/
  bin/berrybridge-run-job        # --watch | --once | job.json
  bin/berrybridge-ensure-sshd    # idempotent sshd start
  etc/berrybridge/agent.conf     # absolute paths
  lib/berrybridge/*.sh           # job handlers
  setup-berrybridge.sh           # creates documents/berrybridge/*
```

Control plane (Bridge-owned staging):

```text
/accounts/1000/shared/documents/berrybridge/
  inbox/*.json
  processed/
  status.json
  agent.log
  RUNME.txt
```

## Integration with BerryCore

1. Ship as `packages/berrybridge-agent-bb10-*.tgz` in BerryCore release or INDEX.
2. Optional post-install hook in `install.sh`:
   ```sh
   if [ -x "$PWD/../berrybridge-agent/setup-berrybridge.sh" ]; then
     sh "$PWD/../berrybridge-agent/setup-berrybridge.sh"
   fi
   ```
3. OpenSSH must be installed (`packages/openssh-*.zip`) before `install_ssh_key` jobs.

## Acceptance tests

See `docs/BB10-SPEC.md` §11 and `berrycore-port/INSTALL.md`.

## Open questions (from spec)

| # | Topic | Current approach |
|---|--------|------------------|
| 1 | Background without Term49 | `nohup berrybridge-agent`; cron `ensure_sshd` after reboot |
| 2 | sshd persistence | Not auto-boot; Bridge sends `ensure_sshd` job |
| 3 | SSH user | Default `blackberry`; configurable in job JSON |
| 4 | Package delivery | Standalone tarball + INDEX entry |
| 5 | Unattended install | `install.sh -y --dir ...` |
