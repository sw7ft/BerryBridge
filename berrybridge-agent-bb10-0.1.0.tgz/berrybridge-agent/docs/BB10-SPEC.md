# Berry Bridge Agent — BerryCore Port Specification

**Version:** 0.1 (draft)  
**Implementation:** `/root/ports/berrybridge-agent/`  
**Package:** `berrybridge-agent-bb10-0.1.0.tgz`  
**Consumer:** Berry Bridge desktop app (Electron)

See the full protocol in the Berry Bridge repo; this file mirrors the port contract for the QNX agent.

## Summary

Build a **BerryCore package** that:

1. Watches `/accounts/1000/shared/documents/berrybridge/inbox/` for JSON jobs
2. Runs `install.sh` from documents non-interactively (`-y --dir ...`)
3. Runs device `ssh-keygen`, merges Bridge `.pub` from documents, starts `sshd` on **2022**
4. Writes `/accounts/1000/shared/documents/berrybridge/status.json` for SMB polling
5. Sets `ssh.ready_for_bridge: true` when sshd is up and `authorized_keys` is populated

## Canonical paths

| Purpose | Path |
|---------|------|
| SMB staging | `/accounts/1000/shared/documents` |
| Agent inbox | `/accounts/1000/shared/documents/berrybridge/inbox` |
| Status | `/accounts/1000/shared/documents/berrybridge/status.json` |
| BerryCore runtime | `/accounts/1000/shared/misc/berrycore` |
| Agent install | `/accounts/1000/shared/misc/berrybridge-agent` |
| authorized_keys | `/accounts/1000/.ssh/authorized_keys` |
| SSH port | **2022** |
| SSH user | **blackberry** |

## Job types (v1)

- `ping`
- `install_berrycore`
- `install_ssh_key`
- `ensure_sshd`

Schemas: `docs/examples/*.json`, `status.json` format in `packaging/lib/berrybridge/common.sh` (`bb_write_status`).

## Commands

```sh
berrybridge-run-job --watch    # poll inbox
berrybridge-run-job --once     # process pending jobs
berrybridge-run-job ping       # health check
berrybridge-ensure-sshd        # start sshd on 2022
```

## Bridge SSH test

```bash
ssh -o BatchMode=yes -o ConnectTimeout=15 \
  -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
  -o KexAlgorithms=diffie-hellman-group1-sha1 \
  -o HostKeyAlgorithms=ssh-rsa -o PubkeyAcceptedAlgorithms=ssh-rsa \
  -p 2022 -i ~/.ssh/id_rsa_bb10 \
  blackberry@<device-ip> echo berrybridge-ok
```

Expected: `berrybridge-ok`
