# berrybridge-agent (BB10)

Berry Bridge **on-device executor**: watches SMB-uploaded JSON jobs under `documents/berrybridge/inbox/`, runs BerryCore install + SSH bootstrap, writes `status.json` for the desktop app to poll.

**Install path:** `/accounts/1000/shared/misc/berrybridge-agent`

## Quick install

```sh
cd /accounts/1000/shared/misc
tar xzf berrybridge-agent-bb10-0.1.0.tgz
sh berrybridge-agent/setup-berrybridge.sh
```

## Start watcher

```sh
nohup /accounts/1000/shared/misc/berrybridge-agent/bin/berrybridge-agent \
  >> /accounts/1000/shared/documents/berrybridge/agent.log 2>&1 &
```

Or one-shot after Bridge uploads jobs:

```sh
/accounts/1000/shared/misc/berrybridge-agent/bin/berrybridge-run-job --once
```

## Bridge paths (SMB `media` share)

| Path | Role |
|------|------|
| `/accounts/1000/shared/documents/berrybridge/inbox/` | Bridge drops `*.json` jobs |
| `/accounts/1000/shared/documents/berrybridge/status.json` | Agent status (Bridge polls) |
| `/accounts/1000/shared/documents/berrybridge/agent.log` | Log |
| `/accounts/1000/shared/documents/berrycore.zip` | BerryCore release |
| `/accounts/1000/shared/documents/id_rsa_bb10.pub` | Desktop SSH public key |

## Job types (v1)

- `ping` — health check
- `install_berrycore` — `sh install.sh -y` from documents
- `install_ssh_key` — device `ssh-keygen`, merge `.pub`, start `sshd` on **2022**
- `ensure_sshd` — idempotent sshd start

Example jobs: `docs/examples/*.json`

## Manual test (Term49)

```sh
export PATH=/accounts/1000/shared/misc/berrybridge-agent/bin:$PATH

berrybridge-run-job ping
cat /accounts/1000/shared/documents/berrybridge/status.json

cp docs/examples/install-berrycore.json \
  /accounts/1000/shared/documents/berrybridge/inbox/
berrybridge-run-job --once
```

## SSH verification (desktop)

```sh
ssh -o BatchMode=yes -o ConnectTimeout=15 \
  -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
  -o KexAlgorithms=diffie-hellman-group1-sha1 \
  -o HostKeyAlgorithms=ssh-rsa -o PubkeyAcceptedAlgorithms=ssh-rsa \
  -p 2022 -i ~/.ssh/id_rsa_bb10 \
  blackberry@<device-ip> echo berrybridge-ok
```

## Dependencies

- BerryCore with **OpenSSH** (`pbpkgadd openssh` or bundled package)
- Writable `/accounts/1000/shared/documents` and `/accounts/1000/.ssh`

## Notes

- **Background watcher:** BB10 may stop user processes when Term49 closes; use `nohup` + cron (`ensure_sshd` job after reboot) until a boot hook exists.
- **SSH user:** Bridge default is `blackberry`; keys live in `/accounts/1000/.ssh/authorized_keys`.
- Full protocol: `docs/BB10-SPEC.md`
